function convertToLocalCurrency(basePrice, applyTax = true) {
  if (currencyRate) {
    let targetPrice = basePrice * currencyRate;
    if (tax > 0 && applyTax) targetPrice += targetPrice * (tax / 100);
    return (
      currencySymbolMap[currencyKey] + numberWithCommas(targetPrice.toFixed(2))
    );
  } else {
    console.error("Exchange rates not available.");
    return null;
  }
}

async function handleQueryCommonHead(query) {
  const currencyDataPromise = chrome.runtime.sendMessage({
    contentScriptQuery: query,
  });

  const currencyData = await currencyDataPromise;

  if (chrome.runtime.lastError) {
    console.error(`Error: ${chrome.runtime.lastError.message}`);
    return;
  }

  return currencyData;
}

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

async function handleQueryCommonTail(rates, updateKey) {
  const lastCurrencyPayload = {
    currency: {
      rates: rates,
    },
  };

  const lastTimePayload = {
    [getUpdateDateKey(updateKey)]: new Date().getTime(),
  };

  await chrome.storage.local.set(lastCurrencyPayload);
  await chrome.storage.local.set(lastTimePayload);

  return lastCurrencyPayload;
}

function getUpdateDateKey(updateKey) {
  return `update${updateKey}Date`;
}

async function updateItems(storedConverter) {
  if (storedConverter) {
    await chrome.storage.local.set({ converterActive: false });
  }
  initItems(true);
  if (storedConverter) {
    await chrome.storage.local.set({ converterActive: true });
  }
}

function getTextNodes(
  node,
  options = {
    level: 1,
    currLevel: 1,
    returnEmpty: false,
  }
) {
  let all = [];
  const { level, currLevel } = options;
  for (let child = node.firstChild; child; child = child.nextSibling) {
    if (child.nodeType == Node.TEXT_NODE) all.push(child);
    else if (currLevel < level)
      all = all.concat(
        getTextNodes(child, { ...options, currLevel: currLevel + 1 })
      );
  }

  if (!all.length && !options.returnEmpty) return [node];

  return all;
}

function getSearchScriptCountry() {
  const script = document.evaluate(
    '//script[contains(text(), "EnableSearchSuggestions")]',
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue;
  let country = null;

  if (script) {
    const result = script.textContent.match(
      /EnableSearchSuggestions\(.+?'(?<cc>[A-Z]{2})',/
    );

    if (result) {
      country = result.groups.cc;

      logger(`Matched country as "${country}" from search script`);

      // console.log(
      //     `%cSteam Currency Converter matched country as "%c${country}%c" from search script`,
      //     "color: green; font-weight: bold;",
      //     "color: gray-smoke; font-weight: bold;",
      //     "color: green; font-weight: bold;"
      // );
    } else {
      console.log(
        "%cSteam Currency Converter failed to find country in search script",
        "color: red; font-weight: bold;"
      );
    }
  }

  return country;
}

function getStoreCurrency() {
  // Select the price currency meta tag
  let currencyElement = document.querySelector("#header_wallet_balance") || "";
  console.log("is it null at first?", !currencyElement);
  if (!currencyElement) {
    if (window.location.href.includes("store.steampowered.com/")) {
      console.log("store'a girdim");
      currencyElement = document.querySelector(".discount_final_price");
      console.log("currencyElement is", currencyElement);
    } else if (window.location.href.includes("steamcommunity.com/market/")) {
      console.log("markete girdim");
      currencyElement = document.querySelector(".normal_price");

    } else {
      console.log("Not in Steam store.");
    }
  }
  let currency = parseCurrencyFromText(currencyElement.textContent) || null;

  console.log("before forcing currency is", currency);
  if (!currency) {
    currency = "USD";

    console.log("Missing priceCurrency, forced to USD");
  }

  if (currency === "USD") {
    // We only need to know the country if currency is USD
    // as all other currencies are uniquely mapped already
    const script = document.evaluate(
      '//script[contains(text(), "EnableSearchSuggestions")]',
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    ).singleNodeValue;
    let country = null;

    if (script) {
      const result = script.textContent.match(
        /EnableSearchSuggestions\(.+?'(?<cc>[A-Z]{2})',/
      );

      if (result) {
        country = result.groups.cc;

        console.log(`Matched country as "${country}" from search script`);
      } else {
        console.log("Failed to find country in search script");
      }
    }

    // Map countries that use USD but different pricing region to their own unique currency name
    // This is done here to not send user's country to the server and to increase cache hits
    // See https://partner.steamgames.com/doc/store/pricing/currencies
    switch (country) {
      case "AZ": // Azerbaijan
      case "AM": // Armenia
      case "BY": // Belarus
      case "GE": // Georgia
      case "KG": // Kyrgyzstan
      case "MD": // Moldova
      case "TJ": // Tajikistan
      case "TM": // Turkmenistan
      case "UZ": // Uzbekistan
      case "BD": // Bangladesh
      case "BT": // Bhutan
      case "NP": // Nepal
      case "PK": // Pakistan
      case "LK": // Sri Lanka
      case "AR": // Argentina
      case "BO": // Bolivia
      case "BZ": // Belize
      case "EC": // Ecuador
      case "GT": // Guatemala
      case "GY": // Guyana
      case "HN": // Honduras
      case "NI": // Nicaragua
      case "PA": // Panama
      case "PY": // Paraguay
      case "SR": // Suriname
      case "SV": // El Salvador
      case "VE": // Venezuela
      case "BH": // Bahrain
      case "DZ": // Algeria
      case "EG": // Egypt
      case "IQ": // Iraq
      case "JO": // Jordan
      case "LB": // Lebanon
      case "LY": // Libya
      case "MA": // Morocco
      case "OM": // Oman
      case "PS": // Palestine
      case "SD": // Sudan
      case "TN": // Tunisia
      case "TR": // Turkey
      case "YE": // Yemen
        currency = "USD";
        break;
    }
  }
  return currency;
}

function getCurrencyByCountryCode(countryCode) {
  let currency;
  let isDefaultValue;
  switch (countryCode) {
    case "AZ":
      currency = "AZN";
      break;
    // Azerbaijan
    case "AM":
      currency = "AMD";
      break;
    case "BY": // Belarus
      currency = "BYN";
      break;
    case "GE": // Georgia
      currency = "GEL";
      break;
    case "KG": // Kyrgyzstan
      currency = "KGS";
      break;
    case "MD": // Moldova
      currency = "MDL";
      break;
    case "TJ": // Tajikistan
      currency = "TJS";
      break;
    case "TM": // Turkmenistan
      currency = "TMT";
      break;
    case "UZ": // Uzbekistan
      currency = "UZS";
      break;
    case "UA":
      currency = "UAH";
      break;

    case "BD":
      currency = "BDT";
      break;
    case "BT":
      currency = "BTN";
      break;

    case "NP":
      currency = "NPR";
      break;
    // Nepal
    case "PK":
      currency = "PKR";
      break;
    // Pakistan
    case "LK": // Sri Lanka
      currency = "LKR";
      break;

    case "AR": // Argentina
      currency = "ARS";
      break;
    case "BO": // Bolivia
      currency = "BOB";
      break;
    case "BZ": // Belize
      currency = "BZD";
      break;
    case "GT": // Guatemala
      currency = "GTQ";
      break;
    case "GY": // Guyana
      currency = "GYD";
      break;
    case "HN": // Honduras
      currency = "HNL";
      break;
    case "NI": // Nicaragua
      currency = "NIO";
      break;
    case "PA": // Panama
      currency = "PAB";
      break;
    case "PY": // Paraguay
      currency = "PYG";
      break;
    case "SR": // Suriname
      currency = "SRD";
      break;

    case "BH": // Bahrain
      currency = "BHD";
      break;
    case "DZ": // Algeria
      currency = "DZD";
      break;
    case "EG": // Egypt
      currency = "EGP";
      break;
    case "IQ": // Iraq
      currency = "IQD";
      break;
    case "JO": // Jordan
      currency = "JOD";
      break;
    case "LB": // Lebanon
      currency = "LBP";
      break;
    case "LY": // Libya
      currency = "LYD";
      break;
    case "MA": // Morocco
      currency = "MAD";
      break;
    case "OM": // Oman
      currency = "OMR";
      break;
    case "PS": // Palestine
      currency = "ILS";
      break;
    case "SD": // Sudan
      currency = "SDG";
      break;
    case "TN": // Tunisia
      currency = "TND";
      break;
    case "TR": // Turkey
      currency = "TRY";
      break;
    case "YE": // Yemen
      currency = "YER";
      break;
    default:
      currency = "TRY";
      isDefaultValue = true;
      break;
  }
  return [currency, isDefaultValue];
}

function getCurrencyBySymbol(symbol) {
  return Object.keys(allCurrencies).find(
    (key) => allCurrencies[key] === symbol
  );
}
function getCurrencySymbolFromString(str) {
  const re =
    /(?:R\$|S\$|\$|RM|kr|Rp|€|¥|£|฿|pуб|P|₫|₩|TL|₴|Mex\$|CDN\$|A\$|HK\$|NT\$|₹|SR|R |DH|CHF|CLP\$|S\/\.|COL\$|NZ\$|ARS\$|₡|₪|₸|KD|zł|QR|\$U)/;
  const match = str.match(re);
  console.log("from getCurrencySymbolFromString", match ? match[0] : "");
  return match ? match[0] : "";
}

function parseCurrencyFromText(text) {
  console.log("from parseCurrencyFromText", text);
  const symbol = getCurrencySymbolFromString(text);
  console.log(`Matched currency symbol as "${symbol}" from text`);
  return getCurrencyBySymbol(symbol);
}

function logger(message) {
  console.log(
    `%c[Steam Currency Converter]: %c${message}`,
    "color: #00aaff; font-weight: bold;",
    "color: #fff;"
  );
}
